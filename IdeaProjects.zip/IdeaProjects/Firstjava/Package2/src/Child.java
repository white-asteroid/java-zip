public class Child extends parent {
    static int a = 0;
    Child(String pros ,int num){
        super(num , pros);
//        this.cnum = this.pubnum;
//        this.var = 44;
    }
    int cnum;

    protected void cfun(){
        System.out.println("Child class fun"+ this.a );
        super.fun();
        this.fun();
    }

}
