 public class parent {
    parent(int pubnum, String pros){
        this.pubnum = pubnum;
        this.pros = pros;
        this.var = 22;
        this.a=4;
    }
    static int a;
    protected void fun(){
//        this.var = 44;
        System.out.println("parent fun called successfully"+this.a);
    }
    private String name;
    final protected int var ;
    public int pubnum;
//    protected static void sfun()
    protected String pros;
}
