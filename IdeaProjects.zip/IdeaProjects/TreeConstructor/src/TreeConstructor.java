import java.util.*;

public class TreeConstructor {
    public static String tc(String[] strArr){
        HashMap<String, Integer> parent = new HashMap<>();
        HashMap<String, Integer> child = new HashMap<>();

        for(int i =0; i<strArr.length;i++){
            // strArr[i].charAt(1);
            int ci= 1;


            String c ="";
            while(strArr[i].charAt(ci) >='0' && strArr[i].charAt(ci) <='9')
                c+=strArr[i].charAt(ci++);
            System.out.println("Child e"+c);
//            if(child.containsKey(c) && child.get(c)==2 )
//            {
//                return "false";
//            }
                if(child.containsKey(c)){
                    System.out.println("child prob");
                    return "false";
                }
                else{
                    child.put(c,1);
                }

            System.out.println("Child map :"+child);
            int pi = ci+1;
            String p ="";
            while(pi<strArr[i].length() &&strArr[i].charAt(pi) >='0' && strArr[i].charAt(pi) <='9')
            {
                p+=strArr[i].charAt(pi);
                pi++;
            }
            System.out.println("parent e "+p+" , "+pi );
            if(parent.containsKey(p) && parent.get(p)==2 )
            {
                return "false";
            }
            else {
                if (parent.containsKey(p)) {
                    parent.put(p,2);
                } else {
                    parent.put(p, 1);
                }
            }
            System.out.println("parent map :"+ parent);
            p="";

        }

        return "true";
    }
}
