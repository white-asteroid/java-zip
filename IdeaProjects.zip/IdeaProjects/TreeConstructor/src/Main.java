public class Main {

    public static void main(String[] args) {
//        System.out.println("Hello world!");
//        String[] sa = {"(1,2)", "(2,4)", "(7,2)","(1,7)"};
        String[] sa =  {"(1,2)", "(3,2)", "(2,12)", "(5,2)"};//{"(2,1)","(3,1)","(4,2)", "(1,4)"};

        System.out.println(Treeonst.tc(sa));
        char ch = '5';
        int c =50;
        c += ch - '0';
        int t = c;
        System.out.println(c);
    }

}