import java.util.*;
public class Treeonst {

    public static boolean isValid(HashMap<Integer,ArrayList<Integer>> tree,int p , int c){
        boolean f =true ;
        System.out.println("Checking for "+ p +" -> "+c);
        if(tree.containsKey(c)){
            ArrayList<Integer> arrli= new ArrayList<>(tree.get(c));
            int i =0,cr;


            for (int j = 0; j < arrli.size(); j++) {
                if(arrli.get(i)==p)
                    return false;
            }

            while(i< arrli.size()){
                cr = arrli.get(i);
                if(tree.containsKey(cr)) {
                   f = isValid(tree, p, cr);
                   if(!f)
                    return false;
                }
                i++;
            }
        }
        return true;
    }

    public static String tc(String[] strArr){
        int ci =1;
        char tch,pch;
        int pi =0,p=0,c=0;
        ArrayList<Integer> tempArr = new ArrayList<>();
        HashMap<Integer,ArrayList<Integer>> tree= new HashMap<>();
        HashMap<Integer,Integer> child= new HashMap<>();

        for (int i = 0; i < strArr.length; i++) {
            p=0;c=0;
            ci=1;
            while (ci < strArr[i].length() && strArr[i].charAt(ci) >= '0' && strArr[i].charAt(ci) <= '9') {
                c *= 10;
                tch = strArr[i].charAt(ci);
                c += tch - '0';
                ci++;
            }
            System.out.println("ci = "+ci);
            pi = ci + 1;
            System.out.println("pi = "+pi);
            while (pi < strArr[i].length() && strArr[i].charAt(pi) >= '0' && strArr[i].charAt(pi) <= '9') {
                p *= 10;
                pch = strArr[i].charAt(pi);
                p += pch - '0';
                pi++;
            }

            System.out.println("current p And c : " + p + " - > " + c);
            if(child.containsKey(c)) {
                System.out.println("Child problem");
                return "false";

            }
            else
                child.put(c,1);
            if (tree.containsKey(p)==true) {
                tempArr.addAll(tree.get(p));
                if (tempArr.size() > 2) {
                    System.out.println("Full child");
                    return "false";
                }

            }
            else {
                tempArr = new ArrayList<>();
                tempArr.add(c);
            }
            if(isValid(tree,p,c))
                    tree.put(p, tempArr);
                else {
                System.out.println("not valid");
                return "false";
            }


            System.out.println(tempArr);
        }

        return "true";
    }
}
