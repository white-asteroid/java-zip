import java.lang.reflect.Array;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        MyArrayList<Integer> myArrLi = new MyArrayList<>();
        ArrayList<Integer> arrli = new ArrayList();
        int arr[] = {1,2,3,4};
        Arrays.sort(arr);
        myArrLi.add(1);
        myArrLi.add(3);
        MyArrayList.sort(arr);
        for (int i = 0; i < 10 ; i++) {
            myArrLi.add(i*10);
        }
        MyArrayList<Integer> list = new MyArrayList<Integer>(myArrLi);
        System.out.println(myArrLi.toString());
        System.out.println(list.toString());
    }
}