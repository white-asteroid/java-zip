import org.jetbrains.annotations.NotNull;

import java.util.Arrays;

public class MyArrayList<T> {
    private Object[] data;
//    public MyArrayList(MyArrayList<Object> myArrLi) {
////        super();
//
////        data = (Object[]) myArrLi;
//
//    }
    public MyArrayList(@NotNull MyArrayList<T> myArrLi) {
        this.data = new Object[myArrLi.size+1];
        for (int i = 0; i < myArrLi.size; i++)
            this.add( myArrLi.get(i) );

        }

    public T get(int index){
//        if(this.data[index] == null)
//            return 0;
        return (T) this.data[index];
    }
    public static void sort(int[] a) {
        System.out.println("Wrong sort called");
    }
    private static int DEFAULT_SIZE  = 10;
    private int size = 0;



    @Override
    public String toString(){
        String temp ="";
        for(int i= 0 ;i< size ;i++) {
            temp += data[i] + ", ";
        }
        temp += data[size];
        return temp;
    }
    public MyArrayList() {
        this.data = new Object[DEFAULT_SIZE];
    }

    public MyArrayList(Object[] data) {
        this.data = data;
    }
    public boolean isFull(){
        return size == data.length -1 ;
    }
    public void reSize() {
        try {
            Object[] newOBJ = new Object[data.length * 2];


        for(int i= 0 ;i< data.length ;i++){
            newOBJ[i] = data[i];
        }
        this.data = newOBJ;
    }
        catch (Exception e){
            System.out.println("Exception is " +e);
        }
    }
    public void add(T num){
        if(isFull())
            reSize();
        data[size] = num;
        size++;
    }

    public T remove(){
        T rem = (T) data[--size];
        return rem;
    }
    public int size(){
        return size;
    }


}
