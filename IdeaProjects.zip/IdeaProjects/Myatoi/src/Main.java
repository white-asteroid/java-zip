public class Main extends Myatoi{
    public static void main(String[] args) {
        System.out.println("Hello world!");
//        System.out.println(myatoi("42"));
//        System.out.println(myatoi("123"));
        System.out.println(myatoi("12365455623"));
//        System.out.println(myatoi("2147483646"));

//        System.out.println(myatoi("abraca dabra -123"));
    }
}