public class Main {

    public static void printPattern(int n){
        int top = n/2;
        int s = top,i=0,j=0;
        for(i=0;i<top;i++) {
            for (j = 0; j < n; j++) {
                if ((i + j) >= top && (i + j) <= s)
//                    System.out.print(i+""+j+" ");
                    System.out.print("*");
                else

                    System.out.print(" ");
            }
            s += 2;
            System.out.println();
        }

        top = n - top;
        int tn = n/2;
        for (; i <=n; i++) {
            int t = s;
            for (j=0; j <=n; j++) {
                if((i+j) >= tn && (i+j)<=s)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            tn+=2;
//            s-=2;
            System.out.println();
        }
    }

    public static void main(String[] args) {
//        System.out.println("Hello world!");
        int n = 7;
        printPattern(n);

    }
}