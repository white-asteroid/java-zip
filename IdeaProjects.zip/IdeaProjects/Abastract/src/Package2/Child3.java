package Package2;

import Package1.parent;

public class Child3 extends parent {
    Child3(){
        super();
//        t = this.pubnum;
    }
    protected void fun(){
        System.out.println("Enjoy your life dude");
    }
}