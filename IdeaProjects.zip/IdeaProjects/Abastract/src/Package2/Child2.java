package Package2;
import Package1.parent;
public class Child2 {
    public static void main(String[] args) {
//        parent a = new parent(10,"shivam");
        Child3 c3 = new Child3();
            c3.fun();
    }

}
