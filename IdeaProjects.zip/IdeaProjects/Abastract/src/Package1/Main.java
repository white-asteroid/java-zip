package Package1;

import java.util.ArrayList;
import java.util.List;

public class Main {
    private static void meth(int... n){
        System.out.println("helo "+ n.getClass());
    }

    public static void main(String[] args) {
        Main.meth(4,5,6,8);
        parent p = new Child("vand", 1);
        Child c = new Child("Shivam",10);
        List li = new ArrayList();
//        p.fun1();
//        p.fun1(1);
        p.fun1(1,2);
        c.fun1(1,2);
        System.out.println(c.cnum);
        System.out.println(p);
    }
}
