package Package1;

public class parent {
    public parent() {

    }
     parent(int pubnum, String pros){
        this.pubnum = pubnum;
        this.pros = pros;
    }
    public int pubnum;
    protected int snum;
    public String pros;
    public void fun1(){
        System.out.println("No arg parent fun1");
    }
    public void fun1(int n,int t){
        System.out.println("2 arg parent fun1");
    }

}
