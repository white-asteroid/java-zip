package Package1;

public class Child extends parent{
    Child(String pros ,int num) {
//        super();
        super(num, pros);
        this.cnum = pubnum;
    }
    public void fun1(int n , int t){
        System.out.println("2 arg child fun1");
    }
    int cnum;

}
