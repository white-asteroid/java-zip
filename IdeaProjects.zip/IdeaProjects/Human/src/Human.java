public class Human implements Cloneable{
    private String name;
    private int marks;
    private String[] nickNames;

    @Override
    public String toString(){
        return "Name: "+this.name+" Marks: "+this.marks + ;
    }
    public Human(String name, int marks,String[] nickNames) {
        this.name = name;
        this.marks = marks;
        this.nickNames = new String[nickNames.length];
        for (int i = 0; i < nickNames.length; i++){
            this.nickNames[i] = nickNames[i];
        }
    }
    //this is shallow copy
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
    // this is deep copy
    public Object DeepClone() throws CloneNotSupportedException {
        Human cp =  (Human)super.clone();
        String[] nn = new String[this.nickNames.length];
        for (int i = 0; i < nn.length; i++) {
            nn[i] = this.nickNames[i];
        }
        cp.nickNames = nn;
        return cp;


    }
}
