public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
//        System.out.println("Hello world!");
        Human shivam = new Human("Shivam", 59,new String[]{"acha bacha","cute ladka","fms kid"});
        Human ashu = new Human("Ashutosh",69, new String[]{"MMKB","C","ASS-HU "});
        Human kush = (Human) ashu.clone();
        System.out.println(ashu.toString());
        System.out.println(shivam.toString());
        Human ashuJNR = (Human) ashu.DeepClone();
        System.out.println(kush.toString());
        System.out.println(ashuJNR.toString());



    }

}