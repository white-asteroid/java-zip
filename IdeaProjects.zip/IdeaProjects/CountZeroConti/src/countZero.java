public class countZero {
    public static void displayArr(int[][] arr){
        for(int i = 0;i<arr.length;i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j]+" , ");
            }
            System.out.println();
        }
        System.out.println();
    }
    public static int[][] Build2DMat(String[] strArr){
        int[][] arr = new int[strArr.length][strArr[0].length()];
        for(int i = 0;i<strArr.length;i++){
            for(int j = 0;j<strArr[i].length();j++){
                arr[i][j]=0;
            }
//            char ch ='A';
//            strArr[0].lastIndexOf(ch);

        }

        char ch;
        for(int i = 0;i<strArr.length;i++){
            for(int j = 0;j<strArr[i].length();j++){
                ch = strArr[i].charAt(j);
                arr[i][j] = ch - '0';
            }
        }
        for(int i = 0;i<arr.length;i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j]+" , ");
            }
            System.out.println();
        }
        return arr;
    }
    public static boolean travArray(int[][] arr,int i ,int j){
        boolean tf =true;
        //go right
        if(i< arr.length && i>=0 && j>=0 &&j<arr[i].length - 1){
            if(arr[i][j+1]==3)
            {
                arr[i][j] =3;
                return false;
            }
            if(arr[i][j+1]==0)
            {
                arr[i][j] =2 ;
                tf = travArray(arr,i,j+1);
                if(!tf)
                    return false;

            }
            // arr[i][j] =3;
        }
        //go left
        if(i>=0 && i< arr.length && j> 0 && j<arr[i].length){
            if(arr[i][j-1]==3)
            {
                arr[i][j] =3;
                return false;
            }
            if(arr[i][j-1]==0)
            {
                arr[i][j] =2 ;
                tf = travArray(arr,i,j-1);
                if(!tf)
                    return false;
                // arr[i][j] =3;
            }
        }
        //go up
        if( i<=arr.length  && i>0 && j>=0 && j<arr[i].length)
        {
            if(arr[i-1][j]==3)
            {
                arr[i][j] =3;
                return false;
            }
            if(arr[i-1][j]==0){
                arr[i][j]=2;
               tf=  travArray(arr,i-1,j);
                if(!tf)
                    return false;
            }
        }
        //go down
        if( i<arr.length -1 && i>=0 && j>=0 && j< arr[i].length)
        {
            if(arr[i+1][j]==3)
            {
                arr[i][j] =3;
                return false;
            }
            if(arr[i+1][j]==0){
                arr[i][j]=2;
                tf=  travArray(arr,i+1,j);
                if(!tf)
                    return false;
            }
        }
        arr[i][j] =3;
        return true;
    }
    public static int BitmapHoles(String[] strArr) {
        int[][] arr = Build2DMat(strArr);
        // code goes here
        int c = countZero(arr);
        return c;
    }
    public static int countZero(int[][] arr){
        boolean cf =false;
        int c =0;
        for(int i = 0;i<arr.length;i++){
            for(int j = 0;j<arr[i].length;j++){
                if(arr[i][j] == 0){
                    cf = travArray(arr,i,j);
                    displayArr(arr);
                    System.out.println("c : "+c+ " cf = "+cf);
                    if(cf)
                        c++;
                }

            }
        }


        return c;
    }

}
