public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        String[] arr =  {"01111", "01101", "00011", "11110"};
        System.out.print(countZero.BitmapHoles(arr));
    }
}