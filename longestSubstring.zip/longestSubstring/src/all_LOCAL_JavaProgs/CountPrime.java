package all_LOCAL_JavaProgs;

import java.util.Arrays;

public class CountPrime {
	 public static int countPrimes(int n) {
		 boolean[] prime = new boolean[n+1];
		 int count = 0;
		 Arrays.fill(prime, true);
		 prime[0] = false;
		 prime[1] =false;
		 for(int i= 2;i < Math.sqrt(n);i++) {
			
			 for(int j = i*2; j<prime.length;j+=i) {
				 prime[j] = false;
				 
			 }
		
		 }
		 for(int i = 1;i<prime.length;i++) {
				if(prime[i])
					{
						System.out.println(prime[i]+" , "+i);
						count++;
					}
			}
		 return count;
	    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(countPrimes(17));
	}

}
