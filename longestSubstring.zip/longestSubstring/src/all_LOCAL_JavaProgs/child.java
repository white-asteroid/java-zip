package all_LOCAL_JavaProgs;

public class child extends parent{
	
	int vol;
	child(int l, int b, int h) {
		super(l, b, h);

		
		// TODO Auto-generated constructor stub
		vol = this.l * this.b * this.h;
//		System.out.println("Child class vol "+vol);
	}
	protected int test(int a) {

		System.out.print("yo bud this is child");
		return 22;
	}
	public void test1() {
		System.out.println("Child called test1");
	}
	
	

}
