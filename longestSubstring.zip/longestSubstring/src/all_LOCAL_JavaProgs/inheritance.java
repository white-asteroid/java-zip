package all_LOCAL_JavaProgs;

public class inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parent p = new child(1,2,3);
		System.out.println(p.test(44)+" || "+p.l+" "+p.b+" "+p.h+" ");
		p.test1();
		child c = new child(1,2,2);
		System.out.println(c.l+" "+c.b+" "+c.h+" "+c.test(48));
		
	}

}
