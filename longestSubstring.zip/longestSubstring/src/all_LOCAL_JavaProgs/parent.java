package all_LOCAL_JavaProgs;

public class parent {
	private int a ;
	int l,b,h;
	parent(int l,int b,int h){
		this.l = l;
		this.b = b;
		this.h = h;

//		System.out.println("Parent class");
		this.a = 44;
	}
	protected int test(int a) {
		this.a = a;

		System.out.print("heelo this is parent dude");
		return (this.a);
	}

	protected void test(int a,long b) {
		this.a = a;
//		return (this.a);
		System.out.print("heelo");
	}
}
