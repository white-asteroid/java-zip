module longestSubstring {
}